#include <iostream>
#include <string>

#include "Control.h"
#include "View.h"
#include "School.h"
#include "Schedule.h"
#include "Course.h"
#include "defs.h"

using namespace std;

int main(){
    Control c;
    c.launch();
    return 0;
}