AUTHOR: 
    Benjamin Mastrangelo, 101270320

PURPOSE: 
    The purpose of this program is to create a schedule of a student in Computer Science at Carleton. 
    The user can select the term (F23 and W24), view the courses, 
        view the schedule, add courses to the schedule and clear the schedule.

LIST OF SOURCE, HEADER AND DATA FILES:
    Control.cc
    Course.cc
    CourseArray.cc
    main.cc
    Schedule.cc
    School.cc
    Time.cc
    View.cc

    Control.h
    Course.h
    CourseArray.h
    Schedule.h
    School.h
    Time.h
    View.h
    defs.h

    Makefile

COMPILATION INSTRUCTIONS:
    make

LAUNCHING INSTRUCTIONS:
    ./a2